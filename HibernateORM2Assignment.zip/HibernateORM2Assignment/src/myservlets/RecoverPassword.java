package myservlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import entitybeans.UserData;
import entitybeans.UserLogin;
import mybeans.OtpGenerate;
import mybeans.sendemail;

/**
 * Servlet implementation class RecoverPassword
 */
@WebServlet("/RecoverPassword")
public class RecoverPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RecoverPassword() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String userid=request.getParameter("userid");
		String secquestion=request.getParameter("secquestion");
		String secans = request.getParameter("secans");
		String status;
		int genotp = 0;
		try
		{
			Session ses;
			Configuration cfg=new Configuration().configure();
			SessionFactory sf=cfg.addAnnotatedClass(UserData.class).buildSessionFactory();
			ses=sf.getCurrentSession();
			ses.beginTransaction();

			Query q=ses.createQuery("from UserData where userid=:id and secquestion=:id1 and secans=:id2");
			q.setParameter("id",userid);
			q.setParameter("id1",secquestion);
			q.setParameter("id2",secans);
			List lst=q.getResultList();
			UserData obj ;
			if(lst.size()>0)
			{
				obj = (UserData) lst.get(0);
				status="found";
				char[] s= OtpGenerate.generateOTP(6);
				String otp=String.valueOf(s);
				
				sendemail eml= new sendemail("Linked Consultant","Recover password","OTP is "+otp,obj.getEmail());
				genotp=Integer.parseInt(otp);
				genotp=genotp+123456;
				response.sendRedirect("RecoverPasswordotp.jsp?uid="+userid+"&status="+status+"&gp="+genotp);
			}
			else {
				status="nf";
				response.sendRedirect("RecoverPasswordotp.jsp?status="+status);
			}
			
			
			
		}
		catch(Exception ex)
		{
			System.out.println("Error : "+ex);
		}
	}

}
