package myservlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entitybeans.UserData;
import entitybeans.UserLogin;

/**
 * Servlet implementation class RegisterEmployer
 */
@WebServlet("/RegisterEmployer")
public class RegisterEmployer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterEmployer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
		String otp=request.getParameter("otp");
		String oriotp=request.getParameter("oriotp");
		if(oriotp.equals(otp))
		{
			String userid=request.getParameter("userid");
		    String name =request.getParameter("name");
		    String email=request.getParameter("email");
		    String usertype=request.getParameter("usertype");
		    String secquestion=request.getParameter("sequestion");
		    String secans=request.getParameter("secans");
		    String pswd=request.getParameter("pswd");
		    
		    Session Ses;
		    Configuration cfg=new Configuration().configure();
		    SessionFactory sf=cfg.addAnnotatedClass(UserLogin.class).buildSessionFactory();

		    Ses=sf.getCurrentSession();
		    Ses.beginTransaction();
		    
		    UserLogin obj = new UserLogin();
		    obj.setUserid(userid);
		    obj.setPswd(pswd);
		    obj.setUsertype(usertype);
		    
		    Ses.save(obj);
		    Ses.getTransaction().commit();
		    
		    Session Ses1;
		    Configuration cfg1=new Configuration().configure();
		    SessionFactory sf1=cfg1.addAnnotatedClass(UserData.class).buildSessionFactory();

		    Ses1=sf1.getCurrentSession();
		    Ses1.beginTransaction();
		    
		    UserData obj1 = new UserData();
		    obj1.setUserid(userid);
		    obj1.setName(name);
		    obj1.setEmail(email);
		    obj1.setSecquestion(secquestion);
		    obj1.setSecans(secans);
		    
		    Ses1.save(obj1);
		    Ses1.getTransaction().commit();
		    response.sendRedirect("RegisterEmployerStatus.jsp?status=pass");
		}
		else
		{
			response.sendRedirect("Failure.jsp?status=otpwrong");
		}}
		catch (Exception e) {
			// TODO: handle exception
			System.out.print(e.getMessage());
		}
	}

}
